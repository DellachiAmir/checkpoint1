#!/bin/bash
cat -n example.log example2.log > access_log.log
head access_log.log
tail access_log.log
logger "VIVA USMA"
grep -i kali /var/log/syslog
grep [plc] access_log.log
grep -E "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}" webserver.log
