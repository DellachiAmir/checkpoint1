Checkpoint Linux fondamentals
Auteur : [AMIR DELLACHI]

Fichiers inclus :
- access_log.log : Logs fusionnés
- webserver.log : Log du serveur web
- checkpoint.sh : Script d'automatisation des commandes
- head_output.txt : Résultat de head
- tail_output.txt : Résultat de tail
- grep_kali_output.txt : Résultat de grep 'kali'
- grep_plc_output.txt : Résultat de grep 'p,l,c'
- grep_ip_output.txt : Résultat de grep des adresses IP

Description :
Ce projet contient toutes les commandes demandées dans le checkpoint.

